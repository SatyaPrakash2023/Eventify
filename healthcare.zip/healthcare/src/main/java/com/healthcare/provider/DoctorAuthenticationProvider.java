package com.healthcare.provider;

import com.healthcare.entity.Doctor;
import com.healthcare.repository.DoctorRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component("doctorAuthenticationProvider")
@RequiredArgsConstructor
public class DoctorAuthenticationProvider implements AuthenticationProvider {
	
	@Autowired
    private DoctorRepository doctorRepository;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();

        Doctor doctor = doctorRepository.findByUsername(username)
                .orElseThrow(() -> new BadCredentialsException("Invalid Doctor Credentials"));

        if (!doctor.getPassword().equals(password)) {
            throw new BadCredentialsException("Invalid Doctor Credentials");
        }

        return new UsernamePasswordAuthenticationToken(username, password,
                Collections.singleton(() -> "ROLE_DOCTOR"));
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
