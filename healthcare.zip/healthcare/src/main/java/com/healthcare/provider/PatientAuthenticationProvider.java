package com.healthcare.provider;

import com.healthcare.entity.Patient;
import com.healthcare.repository.PatientRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component("patientAuthenticationProvider")
@RequiredArgsConstructor
public class PatientAuthenticationProvider implements AuthenticationProvider {
	
	@Autowired
    private PatientRepository patientRepository;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();

        Patient patient = patientRepository.findByUsername(username)
                .orElseThrow(() -> new BadCredentialsException("Invalid Patient Credentials"));

        if (!patient.getPassword().equals(password)) {
            throw new BadCredentialsException("Invalid Patient Credentials");
        }

        return new UsernamePasswordAuthenticationToken(username, password,
                Collections.singleton(() -> "ROLE_PATIENT"));
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
