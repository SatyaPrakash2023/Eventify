package com.healthcare.provider;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

@Component
public class CustomAuthManager implements AuthenticationManager {

    private final AuthenticationProvider adminProvider;
    private final AuthenticationProvider doctorProvider;
    private final AuthenticationProvider patientProvider;

    public CustomAuthManager(
            @Qualifier("adminAuthenticationProvider") AuthenticationProvider adminProvider,
            @Qualifier("doctorAuthenticationProvider") AuthenticationProvider doctorProvider,
            @Qualifier("patientAuthenticationProvider") AuthenticationProvider patientProvider
    ) {
        this.adminProvider = adminProvider;
        this.doctorProvider = doctorProvider;
        this.patientProvider = patientProvider;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();

        // Try each provider in order
        try {
            return adminProvider.authenticate(authentication);
        } catch (BadCredentialsException ignored) {}

        try {
            return doctorProvider.authenticate(authentication);
        } catch (BadCredentialsException ignored) {}

        try {
            return patientProvider.authenticate(authentication);
        } catch (BadCredentialsException ignored) {}

        throw new BadCredentialsException("Invalid Credentials for any user type");
    }
}
