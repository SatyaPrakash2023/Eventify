package com.healthcare.provider;

import com.healthcare.entity.Admin;
import com.healthcare.repository.AdminRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component("adminAuthenticationProvider")
@RequiredArgsConstructor
public class AdminAuthenticationProvider implements AuthenticationProvider {
	
	@Autowired
    private AdminRepository adminRepository;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();

        Admin admin = adminRepository.findByUsername(username)
                .orElseThrow(() -> new BadCredentialsException("Invalid Admin Credentials"));

        if (!admin.getPassword().equals(password)) {
            throw new BadCredentialsException("Invalid Admin Credentials");
        }

        return new UsernamePasswordAuthenticationToken(username, password,
                Collections.singleton(() -> "ROLE_ADMIN"));
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
