package com.healthcare.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@Document(collection = "appointments")
@Getter
@Setter
public class Appointment {
    @Id
    private String id;
    private String doctorId;
    private String patientId;
    private Date appointmentDate;
}
