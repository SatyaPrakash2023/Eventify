package com.healthcare.entity;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "medical_records")
@Getter
@Setter
public class MedicalRecord {
    @Id
    private String id;
    private String patientId;
    private String diagnosis;
    private String treatment;
}

