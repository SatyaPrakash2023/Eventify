package com.healthcare.service;

public class PatientService {

}
