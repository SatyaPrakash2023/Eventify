package com.healthcare.service;

public class MedicalRecordService {

}
