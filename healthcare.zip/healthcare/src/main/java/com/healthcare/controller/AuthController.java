package com.healthcare.controller;

import com.healthcare.config.JwtUtil;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.healthcare.provider.CustomAuthManager;

import java.util.Map;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {
	
	@Autowired
    private CustomAuthManager customAuthManager;
	@Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");

        Authentication auth = customAuthManager.authenticate(
                new UsernamePasswordAuthenticationToken(username, password));

        String role = auth.getAuthorities().iterator().next().getAuthority();
        String token = jwtUtil.generateToken(username, role);

        return Map.of("token", token, "role", role);
    }
}

