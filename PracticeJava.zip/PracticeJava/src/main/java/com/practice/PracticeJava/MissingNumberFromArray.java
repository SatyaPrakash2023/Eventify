/**
 * 
 */
package com.practice.PracticeJava;

import java.util.Scanner;

/**
 * 
 */
public class MissingNumberFromArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub\
//		Scanner sc= new Scanner(System.in);
//		System.out.println("Enter the size of array.. ");
//		int n=sc.nextInt();
//		int[] arr=new int[n+1];
//		int sumofAllNumber= n*(n-1)/2;
//		System.out.println("Sum of all number is "+sumofAllNumber);
//		for(int i=0;i<n;i++) {
//			System.out.println("Enter number to "+(i+1)+"th  add it in your array...");
//			arr[i]=sc.nextInt();
//		}
		int[] arr= {1,2,3,5};
		int n=5;
		int sumofAllNumber= n*(n+1)/2;
		System.out.println("Sum of all number is "+sumofAllNumber);
		int sumOfAllnumberPresentInArray=0;
		for(int i=0;i<arr.length;i++) {
			sumOfAllnumberPresentInArray=sumOfAllnumberPresentInArray+arr[i];
		}
		int missingNumberIs=sumofAllNumber-sumOfAllnumberPresentInArray;
		System.out.println("Missing number is "+missingNumberIs);
		

	}

}
