package com.practice.PracticeJava;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class FirstNonRepetingChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String to check first nonrepeating character..");
		String str=sc.nextLine();
		str=str.toLowerCase();
		
		Map<Character, Integer> map=new LinkedHashMap<>();
		for(char ch:str.toCharArray()) {
			map.put(ch, map.getOrDefault(ch, 0)+1);
		}
		
		System.out.println(map);
		for(char ch:str.toCharArray()) {
			if(map.get(ch)==1) {
				System.out.println("First non repeating character is "+ch);
				break;
			}
		}
		
	}

}
