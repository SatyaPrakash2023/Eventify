/**Array input is [2,7,11,15]
 * target num is 9
 * output is [0,1]
 */
package com.practice.PracticeJava;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 
 */
public class TwoSum {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums= {2,7,11,15}; 
		int target=9;
		//Set approch to check pair sum 
//		int[] outputArray=new int[nums.length];
//		Set<Integer> twoSum=new HashSet<Integer>();
//		int index=0;
//		for(Integer digit:nums) {
//			int diff=target-digit;
//			if(twoSum.contains(diff)) {
//				outputArray[index++]=digit;
//				outputArray[index++]=diff;
//				System.out.println("Pair sum for"+digit+"is "+diff);
//				
//			}
//			twoSum.add(digit);
//		}
		
		//Map Approch to return indexces
		
		Map<Integer, Integer> numsMap=new HashMap<Integer,Integer>();
		for(int i=0;i<nums.length;i++) {
			int diff=target-nums[i];
			if(numsMap.containsKey(diff)) {
				System.out.println("Indices: ["+numsMap.get(diff)+" "+i+"]");
				return;
				//numsMap.put(i,diff);
				
			}
			numsMap.put(nums[i],i);
			
		}
		
		System.out.println(numsMap);
		
	}

}
