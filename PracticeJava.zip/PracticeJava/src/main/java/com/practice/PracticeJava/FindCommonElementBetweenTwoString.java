/**
 * 
 */
package com.practice.PracticeJava;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

/**
 * 
 */
public class FindCommonElementBetweenTwoString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>list1=Arrays.asList(1,2,3,4,5,6,7);
		List<Integer>list2=Arrays.asList(2,3,6);
		List<Integer>commonList=list1.stream().filter(list2::contains).collect(Collectors.toList());
		System.out.println(commonList);
		

	}

}
