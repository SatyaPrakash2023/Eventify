/**
 * list value is [1,2,4,5,6,7,1,2,3,5,9,2,3,4]
 */
package com.practice.PracticeJava;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 
 */
public class RemoveDuplicateFromList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> duplicateList=new ArrayList<Integer>();
		Integer[] ars= {1,2,4,5,6,7,1,2,3,5,9,2,3,4};
		duplicateList=Arrays.asList(ars);
		List<Integer> uniqeList= duplicateList.stream().sorted().distinct().toList();
		System.out.println(uniqeList);
		
		List<Integer> evenList=duplicateList.stream().distinct().filter(n->n%2==0).map(n-> n/2).toList();
		System.out.println(evenList);
	}

}
