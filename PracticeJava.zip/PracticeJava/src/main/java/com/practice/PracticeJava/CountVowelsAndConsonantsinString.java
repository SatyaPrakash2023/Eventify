/**
 * 
 */
package com.practice.PracticeJava;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * 
 */
public class CountVowelsAndConsonantsinString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string to count vowles and Consonants ");
		String str=sc.nextLine();
		str=str.toUpperCase();
		Set<Character>vowel=new HashSet<Character>();
		vowel.add('A');
		vowel.add('E');
		vowel.add('I');
		vowel.add('O');
		vowel.add('U');
		int vowelcount=0,consonantCount=0;
		for(Character ch:str.toCharArray()) {
			if(vowel.contains(ch)) {
				vowelcount++;
			}else {
				consonantCount++;
			}
		}
		
		System.out.println("Entered string vowel present "+vowelcount +"Consonent count is "+consonantCount);
	}

}
