package com.practice.PracticeJava;

import java.io.File;
import java.io.IOException;

public class FileIOoperationPractice {
	public static void main(String[] args) {
		try {
			File newObj=new File("PracticeIO.file");
			System.out.println("Path of the PracticeIO file is"+newObj.getAbsolutePath());
			if(newObj.createNewFile()) {
				System.out.println("File created sucessfully"+newObj.getName());
			}else {
				System.out.println("File already exits in location");
			}
		}catch(IOException e) {
			
			System.out.println("Exception occured"+e.toString());
			e.printStackTrace();
		}	
		
	}
}
