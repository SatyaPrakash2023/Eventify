/**input String is "We refer to a yyddd date format"
 * 
 */
package com.practice.PracticeJava;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 
 */
public class FrequesncyOfEachCharcterInString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Wee refer to aa yyddd date formmat";
		str=str.replace(" ", "");
		Map<Character, Integer>frequencyOfchar= new HashMap<Character, Integer>();
		
		for(Character ch:str.toCharArray()) {
//			if(ch == ' ') {
//				continue;
//			}else {
//			 frequencyOfchar.put(ch, frequencyOfchar.getOrDefault(ch, 0)+1);
//			}
		}
		System.out.println("Map value is...");
		System.out.println("Ch is"+frequencyOfchar);
		
		

	}

}
