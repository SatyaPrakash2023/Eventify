/**
 * 
 */
package com.practice.PracticeJava;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * 
 */
public class FindUniqueWordsFromLineSortAlphabetically {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter a line which u want to check ");
		String str=sc.nextLine();
		str=str.toLowerCase();
		
		List<String> uniquesWords=Arrays.asList(str.split("\\s")). stream().distinct().sorted().toList();
		System.out.println("Sorted unique words list is ");
		System.out.println(uniquesWords);

	}

}
