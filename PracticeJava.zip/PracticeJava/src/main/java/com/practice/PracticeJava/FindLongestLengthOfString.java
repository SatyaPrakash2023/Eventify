/**
 * 
 */
package com.practice.PracticeJava;

import java.util.Scanner;

/**
 * 
 */
public class FindLongestLengthOfString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a line to find longest string");
		String inputLine=sc.nextLine();
		System.out.println("Entered Line is ");
		System.out.println(inputLine);
		
		String[] words=inputLine.split("\\s+");
		String longest="";
		for(String worder:words) {
			if(worder.length()>longest.length()) {
				longest=worder;
			}
		}
		
		System.out.println("Longest string from line is "+longest+" Having size of "+longest.length());
		

	}

}
