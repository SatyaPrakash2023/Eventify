/**
 * 
 */
package com.practice.PracticeJava;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * 
 */
public class FindAllDuplicateFromString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a string to check duplcate character..");
		String  str=sc.nextLine();
		str=str.toLowerCase();
		Map<Character, Integer> duplicateCharacter=new LinkedHashMap<Character, Integer>();
		for(char ch:str.toCharArray()) {
			duplicateCharacter.put(ch, duplicateCharacter.getOrDefault(ch, 0)+1);
		}
		
		duplicateCharacter.forEach((K,V)->{
			if(V>1) {
				System.out.println(K+"-> "+V);
			}
		});
	}
}
