//Find whatever String having length greater than 3
//input is Satya Prakash is a good boy

package com.practice.PracticeJava;

import java.util.Arrays;
import java.util.List;

public class CountNumberOfStringLengthGreaterthan3 {
	public static void main(String[] args) {
		List<String> finNmaes= Arrays.asList("Satya","Is","a","good","boy");
		long count=Arrays.stream("Satya Prakash is a good boy".split(" ")).filter(word->word.length()>=3).count();
		long count2=finNmaes.stream().filter(word->word.length()>=3).count();
		System.out.println("Count is "+count);
		System.out.println("Count2 value is "+count2);
	}
}
