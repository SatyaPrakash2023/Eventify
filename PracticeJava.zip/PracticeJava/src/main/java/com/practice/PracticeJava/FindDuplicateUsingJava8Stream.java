/**
 * 
 */
package com.practice.PracticeJava;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 
 */
public class FindDuplicateUsingJava8Stream {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>list= List.of(1,2,1,2,3,4,5,5,6);
		Set<Integer> set=new HashSet<>();
		Integer duplicate=list.stream().filter(n->!set.add(n)).findFirst().get();
		System.out.println(duplicate);

	}

}
