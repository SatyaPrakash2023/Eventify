/**
 * 
 */
package com.practice.PracticeJava;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 
 */
public class FindWordsLengthMoreThan5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> wordsList=new ArrayList<String>();
		wordsList=Arrays.asList("apple","banana",null,"grapes",null);
		List<String>filterData=new ArrayList<String>();
		filterData=wordsList.stream().filter(words->words!=null && words.length()>5).toList();
		System.out.println(filterData);

	}

}
