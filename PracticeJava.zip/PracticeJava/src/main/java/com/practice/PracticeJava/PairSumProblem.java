/**
 * 
 */
package com.practice.PracticeJava;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 
 */
public class PairSumProblem {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {1,8,7,6,3,2};
		int target=9;
		
		Set<Integer> pairSumMap=new HashSet<>();
		
		for(int num:arr) {
			int diff=target-num;
			if(pairSumMap.contains(diff)) {
				System.out.println("pair sum of"+num+"is "+diff);
			}
			pairSumMap.add(num);
		}
		System.out.println(pairSumMap);

	}

}
