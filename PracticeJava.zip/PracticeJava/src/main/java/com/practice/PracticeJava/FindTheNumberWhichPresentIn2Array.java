/**int[] array1= {1,5,2,3,7,8,4};
		int[] array2= {1,5,9};
		int[] array3= {7,8,6};
		
 * output is 1,5,7,8
 */
package com.practice.PracticeJava;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 
 */
public class FindTheNumberWhichPresentIn2Array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1= {1,5,2,3,7,8,4};
		int[] array2= {1,5,9};
		int[] array3= {7,8,6};
		
		int[] bigArray=new int[array1.length+array2.length+array3.length];
		System.out.println("Big array size is "+bigArray.length);
		int i=0,j=0,k=0;
		while(i<array1.length) {
			bigArray[i]=array1[i];
			i++;
		}
		while(j<array2.length) {
			bigArray[i]=array2[j];
			i++;
			j++;
		}
		while(k<array3.length) {
			bigArray[i]=array3[k];
			i++;
			k++;
		}
		int z=0;
		while(z<bigArray.length) {
			System.out.print(bigArray[z]+" ");
			z++;
		}
		System.out.println();
		
		Map<Integer, Integer> occuranceMap=new HashMap<Integer, Integer>();
		for(Integer number:bigArray) {
			occuranceMap.put(number, occuranceMap.getOrDefault(number, 0)+1);
		}
		System.out.println(occuranceMap);


		for (Map.Entry<Integer, Integer> entry : occuranceMap.entrySet()) {
		            if (entry.getValue() > 1) {
		                System.out.print(entry.getKey() + " ");
		            }
		        }


		
	}

}
