/**
 * 
 */
package com.practice.PracticeJava;

import java.util.Arrays;
import java.util.Scanner;

/**
 * 
 */
public class CountOccuranceOfWord {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a line of words");
		String str1=sc.nextLine();
		str1=str1.toLowerCase();
		System.out.println("Enter words to check count");
		String word=sc.next();
		
		Integer count=(int) Arrays.stream(str1.split(" ")).filter(w->w.equals("java")).count();
		System.out.println("Count of your word is "+word);
		System.out.println(count);

	}

}
