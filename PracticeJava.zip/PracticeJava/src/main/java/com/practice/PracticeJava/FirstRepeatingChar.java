package com.practice.PracticeJava;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class FirstRepeatingChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String to check first repeating character..");
		String str=sc.nextLine();
		str=str.toLowerCase();
		
		Set<Character> repCharCter= new HashSet<Character>();
		Set<Character> repCharCterr= new HashSet<Character>();
		for(char ch:str.toCharArray()) {
			if(repCharCter.contains(ch)) {
				System.out.println("Character is "+ch);
				break;
			}
			repCharCter.add(ch);
		}
		
		

	}

}
