/**Merged two sorted array
 * Array1 having element [3,8,11,56,75]
 * Array2 having element [13,25,56,65,75,85,94]
 * output:[3,8,11,13,25,56,56,65,75,75,85,94]
 */
package com.practice.PracticeJava;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 
 */
public class MergeTwoSortedArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] array1= {3,8,11,56,75};
		int [] array2= {13,25,56,65,75,85,94};
		int size=array1.length+array2.length;
		System.out.println("Size is "+size);
		int[] array3 = new int[size];
		int i=0,j=0,k=0;
		while(i<array1.length && j<array2.length) {
			if(array1[i]<array2[j]) {
				array3[k]=array1[i];
				i++;
			}else {
				array3[k]=array2[j];
				j++;
			}
			k++;
		}
		while(i<array1.length) {
			array3[k]=array1[i];
			i++;
			k++;
		}
		while(j<array2.length) {
			array3[k]=array2[j];
			j++;
			k++;
		}
		List<Integer>list=new ArrayList<>();
		
		
		System.out.println("Sorted overall array is ");
		for(Integer ijk:array3) {
			list.add(ijk);
			System.out.println("Value  is "+ijk);
		}

		System.out.println(list);
	}

}
