/**Input is a10b5c3 and K=16
 * 
 */
package com.practice.PracticeJava;

/**
 * 
 */
public class FindKthCharFromCompressedString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="a10b5c3";
		char[]ch=str.toCharArray();
		for(Character chs:ch) {
			char chaer=chs;
			
		}

	}

}
