/**
 * Array[1,0,2,3,0,0,0,4,5,7,9,]
 */
package com.practice.PracticeJava;

import java.util.Arrays;
import java.util.List;

/**
 * 
 */
public class MoveZeroToEnd {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		List<Integer> endZeroList=Arrays.asList(1,0,2,3,0,0,0,4,5,7,9,0).stream().sorted((a,b)->b-a).toList();
		System.out.println(endZeroList);
		int x=9;
		int w=2;
		 x=x+w;
		 w=x-w;
		 x=x-w;
		 System.out.println("X"+x+" "+w);
		
	}

}
