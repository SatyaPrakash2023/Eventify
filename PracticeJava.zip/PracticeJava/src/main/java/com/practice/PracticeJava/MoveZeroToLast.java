/**
 * 
 */
package com.practice.PracticeJava;

/**
 * 
 */
public class MoveZeroToLast {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
