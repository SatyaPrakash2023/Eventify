package com.practice.PracticeJava.abh;

import java.util.HashMap;

public class FrequencyCount {
	
	public static void main(String[] args) {
		String str="InfiniteGoing"; 
		HashMap<Character,Integer> map = new HashMap();
		for(char c: str.toLowerCase().toCharArray()) {
			map.put(c, map.getOrDefault(c,0)+1);
			
		}
		System.out.println(map);
	}

}
