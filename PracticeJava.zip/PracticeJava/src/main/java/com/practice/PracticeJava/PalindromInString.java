/**
 * input is MADAM
 */
package com.practice.PracticeJava;

/**
 * 
 */
public class PalindromInString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="MADAMs";
		str=str.toLowerCase();
		String nstr="";
		int size = str.length()/2;
		int i=0,j=str.length()-1;
       char[] palArray=str.toCharArray();
       boolean bflag=false;
//		for(int i=str.length();i)
		for(int k=0;k<size;k++) {
			if(palArray[i]==palArray[j]) {
				i++;
				j--;
				bflag=true;
			}else {
				System.out.println("String is not a palindrom");
				break;
				
			}
			
		}
		if(bflag) {
			System.out.println("String is palindrom");
		}
		

	}

}
